'use strict';

/**
 * routes/contacts.js
 * Handles legacy contacts, segments, and campaigns backed by store.json.
 *
 * NOTE: These are the original MVP routes. They are intentionally kept
 * separate from promo-leads (Supabase-backed). Item #2 on the architecture
 * roadmap is to migrate these into Supabase and retire store.json entirely.
 */

const fs = require('fs');
const path = require('path');
const { sendJson, parseJsonBody, getUrlObj, normalizeEmail, nextId } = require('./http');

const DATA_FILE = path.join(__dirname, '..', 'data', 'store.json');

// ---------------------------------------------------------------------------
// store.json I/O
// NOTE: readStore/writeStore have a read-modify-write race condition under
// concurrent requests. This is a known limitation documented in the
// architecture roadmap (#2 - migrate to Supabase). Do not add new features
// that depend on this store; use Supabase for new data.
// ---------------------------------------------------------------------------

function ensureDataFile() {
  if (!fs.existsSync(DATA_FILE)) {
    const initial = { contacts: [], segments: [], campaigns: [], events: [] };
    fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
    fs.writeFileSync(DATA_FILE, JSON.stringify(initial, null, 2));
  }
}

function readStore() {
  ensureDataFile();
  return JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8'));
}

function writeStore(store) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(store, null, 2));
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function contactMatchesSegment(contact, segment) {
  if (!segment || !segment.rules || segment.rules.length === 0) return true;
  return segment.rules.every((rule) => {
    const field = String(rule.field || '').toLowerCase();
    const op = String(rule.operator || '').toLowerCase();
    const value = String(rule.value || '').toLowerCase();
    const source = String(contact[field] ?? '').toLowerCase();
    if (op === 'contains') return source.includes(value);
    if (op === 'equals') return source === value;
    return false;
  });
}

function computeCampaignStats(campaign, events = []) {
  const sent = campaign.sentCount || 0;
  const openCount = events.filter((e) => e.campaignId === campaign.id && e.type === 'open').length;
  const clickCount = events.filter((e) => e.campaignId === campaign.id && e.type === 'click').length;
  return {
    sent,
    opens: openCount,
    clicks: clickCount,
    openRate: sent ? Number(((openCount / sent) * 100).toFixed(1)) : 0,
    clickRate: sent ? Number(((clickCount / sent) * 100).toFixed(1)) : 0
  };
}

// ---------------------------------------------------------------------------
// Route handlers — return true if they handled the request, false otherwise
// ---------------------------------------------------------------------------

async function handleContacts(req, res, pathname, method) {
  // GET /api/contacts
  if (pathname === '/api/contacts' && method === 'GET') {
    const store = readStore();
    return sendJson(res, 200, { contacts: store.contacts }), true;
  }

  // POST /api/contacts
  if (pathname === '/api/contacts' && method === 'POST') {
    const body = await parseJsonBody(req);
    const email = normalizeEmail(body.email);
    if (!email || !email.includes('@')) {
      return sendJson(res, 400, { error: 'Valid email is required' }), true;
    }
    const store = readStore();
    if (store.contacts.find((c) => c.email === email)) {
      return sendJson(res, 409, { error: 'Contact with this email already exists' }), true;
    }
    const contact = {
      id: nextId('contact'),
      email,
      firstName: String(body.firstName || '').trim(),
      lastName: String(body.lastName || '').trim(),
      city: String(body.city || '').trim(),
      tags: Array.isArray(body.tags) ? body.tags.map((t) => String(t).trim()).filter(Boolean) : [],
      createdAt: new Date().toISOString()
    };
    store.contacts.push(contact);
    writeStore(store);
    return sendJson(res, 201, { contact }), true;
  }

  // POST /api/contacts/import
  if (pathname === '/api/contacts/import' && method === 'POST') {
    const body = await parseJsonBody(req);
    if (!Array.isArray(body.contacts)) {
      return sendJson(res, 400, { error: 'contacts must be an array' }), true;
    }
    const store = readStore();
    const existingEmails = new Set(store.contacts.map((c) => c.email));
    let created = 0;
    for (const row of body.contacts) {
      const email = normalizeEmail(row.email);
      if (!email || !email.includes('@') || existingEmails.has(email)) continue;
      const contact = {
        id: nextId('contact'),
        email,
        firstName: String(row.firstName || '').trim(),
        lastName: String(row.lastName || '').trim(),
        city: String(row.city || '').trim(),
        tags: Array.isArray(row.tags) ? row.tags.map((t) => String(t).trim()).filter(Boolean) : [],
        createdAt: new Date().toISOString()
      };
      store.contacts.push(contact);
      existingEmails.add(email);
      created += 1;
    }
    writeStore(store);
    return sendJson(res, 201, { imported: created, total: store.contacts.length }), true;
  }

  return false;
}

async function handleSegments(req, res, pathname, method) {
  // GET /api/segments
  if (pathname === '/api/segments' && method === 'GET') {
    const store = readStore();
    const segments = store.segments.map((segment) => {
      const audience = store.contacts.filter((c) => contactMatchesSegment(c, segment));
      return { ...segment, audienceSize: audience.length };
    }).sort((a, b) => {
      const ta = String(a.updatedAt || a.createdAt || '');
      const tb = String(b.updatedAt || b.createdAt || '');
      return tb.localeCompare(ta);
    });
    return sendJson(res, 200, { segments }), true;
  }

  // POST /api/segments
  if (pathname === '/api/segments' && method === 'POST') {
    const body = await parseJsonBody(req);
    const name = String(body.name || '').trim();
    if (!name) return sendJson(res, 400, { error: 'Segment name is required' }), true;
    const cleanedRules = (Array.isArray(body.rules) ? body.rules : [])
      .map((r) => ({
        field: String(r.field || '').trim(),
        operator: String(r.operator || '').trim(),
        value: String(r.value || '').trim()
      }))
      .filter((r) => r.field && r.operator && r.value);
    const now = new Date().toISOString();
    const segment = {
      id: nextId('segment'),
      name,
      rules: cleanedRules,
      definition: body?.definition && typeof body.definition === 'object' ? body.definition : null,
      createdAt: now,
      updatedAt: now
    };
    const store = readStore();
    store.segments.push(segment);
    writeStore(store);
    return sendJson(res, 201, { segment }), true;
  }

  // PUT /api/segments/:id
  const segmentMatch = pathname.match(/^\/api\/segments\/([^/]+)$/);
  if (segmentMatch && method === 'PUT') {
    const body = await parseJsonBody(req);
    const store = readStore();
    const id = decodeURIComponent(segmentMatch[1]);
    const idx = store.segments.findIndex((s) => String(s.id) === id);
    if (idx < 0) return sendJson(res, 404, { error: 'Segment not found' }), true;
    const prev = store.segments[idx];
    const name = body.name !== undefined ? String(body.name || '').trim() : prev.name;
    if (!name) return sendJson(res, 400, { error: 'Segment name is required' }), true;
    const rules = Array.isArray(body.rules) ? body.rules : prev.rules || [];
    const cleanedRules = rules
      .map((r) => ({
        field: String(r.field || '').trim(),
        operator: String(r.operator || '').trim(),
        value: String(r.value || '').trim()
      }))
      .filter((r) => r.field && r.operator && r.value);
    const updated = {
      ...prev,
      name,
      rules: cleanedRules,
      definition: body?.definition && typeof body.definition === 'object'
        ? body.definition
        : (prev.definition || null),
      updatedAt: new Date().toISOString()
    };
    store.segments[idx] = updated;
    writeStore(store);
    return sendJson(res, 200, { segment: updated }), true;
  }

  // DELETE /api/segments/:id
  if (segmentMatch && method === 'DELETE') {
    const store = readStore();
    const id = decodeURIComponent(segmentMatch[1]);
    const before = store.segments.length;
    store.segments = store.segments.filter((s) => String(s.id) !== id);
    if (store.segments.length === before) return sendJson(res, 404, { error: 'Segment not found' }), true;
    writeStore(store);
    return sendJson(res, 200, { deleted: true, segmentId: id }), true;
  }

  return false;
}

async function handleCampaigns(req, res, pathname, method) {
  // GET /api/campaigns
  if (pathname === '/api/campaigns' && method === 'GET') {
    const store = readStore();
    const campaigns = store.campaigns.map((c) => ({ ...c, stats: computeCampaignStats(c, store.events) }));
    return sendJson(res, 200, { campaigns }), true;
  }

  // POST /api/campaigns
  if (pathname === '/api/campaigns' && method === 'POST') {
    const body = await parseJsonBody(req);
    const name = String(body.name || '').trim();
    const subject = String(body.subject || '').trim();
    const content = String(body.content || '').trim();
    const segmentId = String(body.segmentId || '').trim();
    if (!name || !subject || !content) {
      return sendJson(res, 400, { error: 'name, subject, and content are required' }), true;
    }
    const store = readStore();
    if (segmentId && !store.segments.find((s) => s.id === segmentId)) {
      return sendJson(res, 400, { error: 'Selected segment does not exist' }), true;
    }
    const campaign = {
      id: nextId('campaign'),
      name, subject, content,
      segmentId: segmentId || null,
      status: 'draft',
      sentCount: 0,
      createdAt: new Date().toISOString(),
      lastSentAt: null
    };
    store.campaigns.push(campaign);
    writeStore(store);
    return sendJson(res, 201, { campaign }), true;
  }

  // POST /api/campaigns/:id/send
  const sendMatch = pathname.match(/^\/api\/campaigns\/([^/]+)\/send$/);
  if (sendMatch && method === 'POST') {
    const store = readStore();
    const campaign = store.campaigns.find((c) => c.id === sendMatch[1]);
    if (!campaign) return sendJson(res, 404, { error: 'Campaign not found' }), true;
    const segment = campaign.segmentId ? store.segments.find((s) => s.id === campaign.segmentId) : null;
    const recipients = store.contacts.filter((c) => !segment || contactMatchesSegment(c, segment));
    const now = new Date().toISOString();
    campaign.status = 'sent';
    campaign.sentCount = recipients.length;
    campaign.lastSentAt = now;
    const newEvents = [];
    recipients.forEach((recipient) => {
      const willOpen = Math.random() < 0.45;
      const willClick = willOpen && Math.random() < 0.2;
      if (willOpen) newEvents.push({ id: nextId('event'), campaignId: sendMatch[1], contactId: recipient.id, type: 'open', at: now });
      if (willClick) newEvents.push({ id: nextId('event'), campaignId: sendMatch[1], contactId: recipient.id, type: 'click', at: now });
    });
    store.events.push(...newEvents);
    writeStore(store);
    return sendJson(res, 200, {
      message: 'Campaign send simulated',
      recipients: recipients.length,
      stats: computeCampaignStats(campaign, store.events)
    }), true;
  }

  return false;
}

async function handle(req, res, pathname, method) {
  if (await handleContacts(req, res, pathname, method)) return true;
  if (await handleSegments(req, res, pathname, method)) return true;
  if (await handleCampaigns(req, res, pathname, method)) return true;
  return false;
}

module.exports = { handle };
