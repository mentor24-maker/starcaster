'use strict';

/**
 * routes/index.js
 * Central API dispatcher. This is the SINGLE SOURCE OF TRUTH for all routes.
 *
 * Both entry points import from here:
 *   - server.js       (local dev, Node HTTP server)
 *   - api/[...slug].js (Vercel serverless)
 *
 * To add a new route group:
 *   1. Create routes/myModule.js with a handle(req, res, pathname, method) function
 *   2. Import it below and add it to the ROUTE_MODULES array
 *   That's it. Do NOT add routes directly to server.js or api/[...slug].js.
 */

const { sendJson, setCors, getUrlObj } = require('./http');

const settings  = require('./settings');
const harvest   = require('./harvest');
const promoLeads = require('./promoLeads');
const contacts  = require('./contacts');

// Route modules are tried in order. First match wins.
// Put more specific/higher-traffic modules first.
const ROUTE_MODULES = [
  settings,
  harvest,
  promoLeads,
  contacts
];

async function handleRequest(req, res) {
  setCors(res);

  // Handle CORS preflight globally
  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    return res.end();
  }

  const urlObj = getUrlObj(req);
  const pathname = urlObj.pathname;
  const method = req.method;

  try {
    for (const mod of ROUTE_MODULES) {
      const handled = await mod.handle(req, res, pathname, method);
      if (handled) return;
    }
    // No module handled the request
    sendJson(res, 404, { error: `API route not found: ${method} ${pathname}` });
  } catch (err) {
    console.error(`[routes] Unhandled error for ${method} ${pathname}:`, err);
    sendJson(res, 500, { error: err.message || 'Internal server error' });
  }
}

module.exports = { handleRequest };
