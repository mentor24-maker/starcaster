'use strict';

/**
 * routes/harvest.js
 * All /api/harvest/* routes: direct web harvest, YouTube harvest, and job management.
 */

const { sendJson, parseJsonBody, getUrlObj } = require('./http');
const { listHarvestJobs } = require('../lib/harvestJobs');
const { upsertMirroredHarvestJob, deleteMirroredHarvestJob } = require('../lib/harvestMirror');
const { runDirectHarvest, listDirectHarvestRuns, getDirectHarvestRun } = require('../lib/directHarvest');
const { runYoutubeHarvest } = require('../lib/youtubeHarvest');
const {
  createYoutubeHarvestRun,
  listYoutubeHarvestRuns,
  getYoutubeHarvestRun,
  deleteYoutubeHarvestRun,
  runSummary
} = require('../lib/youtubeHarvestRuns');

async function handle(req, res, pathname, method) {
  const urlObj = getUrlObj(req);

  // GET /api/harvest/jobs
  if (pathname === '/api/harvest/jobs' && method === 'GET') {
    const limit = Number(urlObj.searchParams.get('limit') || 200);
    const result = await listHarvestJobs(limit);
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error }), true;
    return sendJson(res, 200, { jobs: result.data || [] }), true;
  }

  // DELETE /api/harvest/jobs/:id
  const harvestJobMatch = pathname.match(/^\/api\/harvest\/jobs\/([^/]+)$/);
  if (harvestJobMatch && method === 'DELETE') {
    const result = deleteMirroredHarvestJob(decodeURIComponent(harvestJobMatch[1]));
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error }), true;
    return sendJson(res, 200, result.data), true;
  }

  // GET /api/harvest/direct-runs
  if (pathname === '/api/harvest/direct-runs' && method === 'GET') {
    const limit = Number(urlObj.searchParams.get('limit') || 20);
    return sendJson(res, 200, { runs: listDirectHarvestRuns(limit) }), true;
  }

  // GET /api/harvest/direct-runs/:id
  const directRunMatch = pathname.match(/^\/api\/harvest\/direct-runs\/([^/]+)$/);
  if (directRunMatch && method === 'GET') {
    const run = getDirectHarvestRun(decodeURIComponent(directRunMatch[1]));
    if (!run) return sendJson(res, 404, { error: 'Run not found' }), true;
    return sendJson(res, 200, { run }), true;
  }

  // POST /api/harvest/direct-run
  if (pathname === '/api/harvest/direct-run' && method === 'POST') {
    const body = await parseJsonBody(req);
    if (body?.manual_confirmed !== true) {
      return sendJson(res, 400, { error: 'manual_confirmed=true is required' }), true;
    }
    const run = await runDirectHarvest(body || {});
    return sendJson(res, 201, { run }), true;
  }

  // POST /api/harvest/youtube
  if (pathname === '/api/harvest/youtube' && method === 'POST') {
    const body = await parseJsonBody(req);
    if (body?.manual_confirmed !== true) {
      return sendJson(res, 400, { error: 'manual_confirmed=true is required' }), true;
    }
    const result = await runYoutubeHarvest(body || {});
    const createRes = await createYoutubeHarvestRun(body || {}, result);
    if (!createRes.ok) {
      return sendJson(res, createRes.status || 500, { error: createRes.error, details: createRes.raw || null }), true;
    }
    return sendJson(res, 200, { result, run: runSummary(createRes.data) }), true;
  }

  // GET /api/harvest/youtube-runs
  if (pathname === '/api/harvest/youtube-runs' && method === 'GET') {
    const limit = Number(urlObj.searchParams.get('limit') || 20);
    const result = await listYoutubeHarvestRuns(limit);
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error, details: result.raw || null }), true;
    return sendJson(res, 200, { runs: result.data || [] }), true;
  }

  // POST /api/harvest/youtube-runs/:id/rerun
  const youtubeRerunMatch = pathname.match(/^\/api\/harvest\/youtube-runs\/([^/]+)\/rerun$/);
  if (youtubeRerunMatch && method === 'POST') {
    const body = await parseJsonBody(req);
    if (body?.manual_confirmed !== true) {
      return sendJson(res, 400, { error: 'manual_confirmed=true is required' }), true;
    }
    const priorRes = await getYoutubeHarvestRun(decodeURIComponent(youtubeRerunMatch[1]));
    if (!priorRes.ok) return sendJson(res, priorRes.status || 500, { error: priorRes.error, details: priorRes.raw || null }), true;
    const prior = priorRes.data;
    const result = await runYoutubeHarvest({ video_url: prior.video_url, manual_confirmed: true });
    const createRes = await createYoutubeHarvestRun({ video_url: prior.video_url, manual_confirmed: true }, result);
    if (!createRes.ok) {
      return sendJson(res, createRes.status || 500, { error: createRes.error, details: createRes.raw || null }), true;
    }
    return sendJson(res, 200, { result, run: runSummary(createRes.data), rerun_of: prior.run_id }), true;
  }

  // GET /api/harvest/youtube-runs/:id
  const youtubeRunMatch = pathname.match(/^\/api\/harvest\/youtube-runs\/([^/]+)$/);
  if (youtubeRunMatch && method === 'GET') {
    const result = await getYoutubeHarvestRun(decodeURIComponent(youtubeRunMatch[1]));
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error, details: result.raw || null }), true;
    return sendJson(res, 200, { run: result.data }), true;
  }

  // DELETE /api/harvest/youtube-runs/:id
  if (youtubeRunMatch && method === 'DELETE') {
    const result = await deleteYoutubeHarvestRun(decodeURIComponent(youtubeRunMatch[1]));
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error, details: result.raw || null }), true;
    return sendJson(res, 200, result.data), true;
  }

  return false;
}

module.exports = { handle };
