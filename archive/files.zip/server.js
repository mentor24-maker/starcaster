'use strict';

/**
 * server.js — Local development entry point.
 *
 * This file handles only:
 *   1. Static file serving from public/
 *   2. Delegating /api/* requests to routes/index.js
 *
 * All API business logic lives in routes/. Do not add route handlers here.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const { handleRequest } = require('./routes/index');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function serveStatic(req, res) {
  let pathname = new URL(req.url, 'http://localhost').pathname;
  if (pathname === '/') pathname = '/index.html';

  const safePath = path.normalize(pathname).replace(/^\.\.([/\\]|$)/, '');
  const filePath = path.join(PUBLIC_DIR, safePath);

  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    return res.end('Forbidden');
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404);
      return res.end('Not found');
    }
    const ext = path.extname(filePath).toLowerCase();
    const type = MIME_TYPES[ext] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': type });
    return res.end(data);
  });
}

const server = http.createServer((req, res) => {
  if (req.url.startsWith('/api/')) {
    return handleRequest(req, res);
  }
  return serveStatic(req, res);
});

server.listen(PORT, () => {
  console.log(`[APP] Alphire Promo Platform running at http://localhost:${PORT}`);
});
