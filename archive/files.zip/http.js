'use strict';

/**
 * routes/http.js
 * Shared HTTP utilities for all route handlers.
 * Both server.js (local) and api/[...slug].js (Vercel) import from here.
 */

const MAX_BODY_BYTES = 10_000_000;

function sendJson(res, status, payload) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.end(JSON.stringify(payload));
}

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

function parseJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk;
      if (body.length > MAX_BODY_BYTES) {
        reject(new Error('Request body too large (max 10MB)'));
      }
    });
    req.on('end', () => {
      if (!body) return resolve({});
      try {
        resolve(JSON.parse(body));
      } catch {
        reject(new Error('Invalid JSON body'));
      }
    });
    req.on('error', reject);
  });
}

function getUrlObj(req) {
  const host = req.headers.host || 'localhost';
  return new URL(req.url, `http://${host}`);
}

function normalizeEmail(email) {
  return String(email || '').trim().toLowerCase();
}

function nextId(prefix) {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

module.exports = { sendJson, setCors, parseJsonBody, getUrlObj, normalizeEmail, nextId };
