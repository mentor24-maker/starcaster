'use strict';

/**
 * routes/promoLeads.js
 * All /api/promo-leads/* routes. Supabase-backed.
 */

const { sendJson, parseJsonBody, getUrlObj } = require('./http');
const {
  listFieldConfigs,
  createFieldConfig,
  updateFieldConfig,
  deleteFieldConfig,
  listPromoLeads,
  createPromoLead,
  updatePromoLead,
  deletePromoLead,
  detectPromoLeadColumns,
  importPromoLeads
} = require('../lib/promoLeads');

async function handle(req, res, pathname, method) {
  const urlObj = getUrlObj(req);

  // GET /api/promo-leads/fields
  if (pathname === '/api/promo-leads/fields' && method === 'GET') {
    const result = await listFieldConfigs();
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error }), true;
    return sendJson(res, 200, { fields: result.data || [] }), true;
  }

  // POST /api/promo-leads/fields
  if (pathname === '/api/promo-leads/fields' && method === 'POST') {
    const body = await parseJsonBody(req);
    const result = await createFieldConfig(body);
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error }), true;
    return sendJson(res, 201, { field: Array.isArray(result.data) ? result.data[0] : result.data }), true;
  }

  // PUT /api/promo-leads/fields/:id
  const fieldMatch = pathname.match(/^\/api\/promo-leads\/fields\/([^/]+)$/);
  if (fieldMatch && method === 'PUT') {
    const body = await parseJsonBody(req);
    const result = await updateFieldConfig(fieldMatch[1], body);
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error }), true;
    return sendJson(res, 200, { field: Array.isArray(result.data) ? result.data[0] : result.data }), true;
  }

  // DELETE /api/promo-leads/fields/:id
  if (fieldMatch && method === 'DELETE') {
    const result = await deleteFieldConfig(fieldMatch[1]);
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error }), true;
    return sendJson(res, 200, { deleted: true }), true;
  }

  // POST /api/promo-leads/import
  if (pathname === '/api/promo-leads/import' && method === 'POST') {
    const body = await parseJsonBody(req);
    const result = await importPromoLeads(body.contacts);
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error }), true;
    return sendJson(res, 200, result.data), true;
  }

  // POST /api/promo-leads/columns/check
  if (pathname === '/api/promo-leads/columns/check' && method === 'POST') {
    const body = await parseJsonBody(req);
    const result = await detectPromoLeadColumns(body.columns);
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error }), true;
    return sendJson(res, 200, { columns: result.data || [] }), true;
  }

  // GET /api/promo-leads
  if (pathname === '/api/promo-leads' && method === 'GET') {
    const limit = Number(urlObj.searchParams.get('limit') || 500);
    const result = await listPromoLeads(limit);
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error }), true;
    return sendJson(res, 200, { leads: result.data || [] }), true;
  }

  // POST /api/promo-leads
  if (pathname === '/api/promo-leads' && method === 'POST') {
    const body = await parseJsonBody(req);
    const result = await createPromoLead(body);
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error }), true;
    return sendJson(res, 201, { lead: Array.isArray(result.data) ? result.data[0] : result.data }), true;
  }

  // PUT /api/promo-leads/:id
  const leadMatch = pathname.match(/^\/api\/promo-leads\/([^/]+)$/);
  if (leadMatch && method === 'PUT') {
    const body = await parseJsonBody(req);
    const result = await updatePromoLead(leadMatch[1], body);
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error }), true;
    return sendJson(res, 200, { lead: Array.isArray(result.data) ? result.data[0] : result.data }), true;
  }

  // DELETE /api/promo-leads/:id
  if (leadMatch && method === 'DELETE') {
    const result = await deletePromoLead(leadMatch[1]);
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error }), true;
    return sendJson(res, 200, { deleted: true }), true;
  }

  return false;
}

module.exports = { handle };
