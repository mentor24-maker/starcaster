'use strict';

/**
 * routes/settings.js
 * All /api/settings/* and /api/openclaw/* routes.
 */

const { sendJson, parseJsonBody } = require('./http');
const {
  listApiSchemas,
  listApiConfigsMasked,
  upsertApiConfig,
  getApiConfig,
  deleteApiConfig
} = require('../lib/apiSettings');
const { relayOpenClaw } = require('../lib/openclawGateway');
const { upsertMirroredHarvestJob } = require('../lib/harvestMirror');
const {
  hasSupabaseConfig,
  listDatabaseTables,
  createDatabaseField
} = require('../lib/promoLeads');

async function handle(req, res, pathname, method) {
  // GET /api/health
  if (pathname === '/api/health' && method === 'GET') {
    return sendJson(res, 200, {
      ok: true,
      now: new Date().toISOString(),
      promoLeads: { supabaseConfigured: hasSupabaseConfig() }
    }), true;
  }

  // GET /api/settings/apis/schema
  if (pathname === '/api/settings/apis/schema' && method === 'GET') {
    return sendJson(res, 200, { providers: listApiSchemas() }), true;
  }

  // GET /api/settings/apis
  if (pathname === '/api/settings/apis' && method === 'GET') {
    return sendJson(res, 200, { configs: listApiConfigsMasked() }), true;
  }

  // POST /api/settings/apis
  if (pathname === '/api/settings/apis' && method === 'POST') {
    const body = await parseJsonBody(req);
    const result = await upsertApiConfig(body);
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error }), true;
    return sendJson(res, 200, result.data), true;
  }

  // GET /api/settings/apis/:provider
  const apiProviderMatch = pathname.match(/^\/api\/settings\/apis\/([^/]+)$/);
  if (apiProviderMatch && method === 'GET') {
    const result = getApiConfig(apiProviderMatch[1]);
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error }), true;
    return sendJson(res, 200, result.data), true;
  }

  // DELETE /api/settings/apis/:provider
  if (apiProviderMatch && method === 'DELETE') {
    const result = deleteApiConfig(apiProviderMatch[1]);
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error }), true;
    return sendJson(res, 200, result.data), true;
  }

  // GET /api/settings/database/tables
  if (pathname === '/api/settings/database/tables' && method === 'GET') {
    const result = await listDatabaseTables();
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error }), true;
    return sendJson(res, 200, { tables: result.data || [] }), true;
  }

  // POST /api/settings/database/fields
  if (pathname === '/api/settings/database/fields' && method === 'POST') {
    const body = await parseJsonBody(req);
    const result = await createDatabaseField(body);
    if (!result.ok) return sendJson(res, result.status || 500, { error: result.error }), true;
    return sendJson(res, 201, result.data), true;
  }

  // POST /api/openclaw/:action
  const openClawMatch = pathname.match(/^\/api\/openclaw\/([^/]+)$/);
  if (openClawMatch && method === 'POST') {
    const body = await parseJsonBody(req);
    const result = await relayOpenClaw(openClawMatch[1], body);
    if (!result.ok) {
      return sendJson(res, result.status || 500, { error: result.error, details: result.data || null }), true;
    }
    const responsePayload = { action: openClawMatch[1], result: result.data };
    upsertMirroredHarvestJob(openClawMatch[1], body, responsePayload);
    return sendJson(res, result.status || 200, responsePayload), true;
  }

  return false;
}

module.exports = { handle };
